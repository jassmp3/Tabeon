/* TABΞON By Jass — service worker (Manifest V3)
 * Stores per-tab settings keyed by tab ID, pushes state to each tab's content
 * script, tracks the active tab, and optionally uses native tab groups. */
importScripts('shared.js');
const T = globalThis.TABEON;

// Serialize every read-modify-write so rapid clicks never clobber each other.
let queue = Promise.resolve();
const run = fn => { const p = queue.then(fn); queue = p.catch(() => {}); return p; };

const DEFAULTS = { power: true, autoGroup: false, tabs: {}, grouped: {} };
const load = () => chrome.storage.local.get(DEFAULTS);
const WEB = /^(https?|file):/i;
const isCfg = c => !!(c && (c.color || c.note || c.customName));

function stateFor(d, tab) {
  const c = d.tabs[tab.id] || {};
  return {
    enabled: !!d.power,
    color: c.color || '',
    note: c.note || '',
    customName: c.customName || '',
    highlight: c.highlight !== false,
    active: !!tab.active
  };
}

async function inject(tabId) {
  await chrome.scripting.executeScript({ target: { tabId }, files: ['shared.js', 'content.js'] });
}

async function push(tab, d) {
  if (!tab || tab.id == null || tab.discarded) return;
  const msg = { type: 'tabeon-state', state: stateFor(d, tab) };
  try {
    await chrome.tabs.sendMessage(tab.id, msg);
  } catch (e) {
    // Content script missing (tab opened before install/update). Inject without reloading the tab.
    if (!WEB.test(tab.url || '') || !isCfg(d.tabs[tab.id])) return;
    try { await inject(tab.id); await chrome.tabs.sendMessage(tab.id, msg); } catch (e2) {}
  }
}

async function pushConfigured(d, query) {
  const tabs = await chrome.tabs.query(query || {});
  await Promise.all(tabs.filter(t => isCfg(d.tabs[t.id])).map(t => push(t, d)));
}

/* ---------- optional native tab groups ---------- */
async function syncGroups() {
  try {
    const d = await load();
    const tabs = await chrome.tabs.query({});
    const byId = new Map(tabs.map(t => [t.id, t]));
    const grouped = { ...d.grouped };
    const want = !!(d.power && d.autoGroup);

    const ungroup = [];
    for (const id of Object.keys(grouped)) {
      const t = byId.get(+id);
      if (!t || t.groupId === -1) { delete grouped[id]; continue; } // gone, or user removed it
      if (!want || !(d.tabs[id] && d.tabs[id].color)) { ungroup.push(+id); delete grouped[id]; }
    }
    if (ungroup.length) { try { await chrome.tabs.ungroup(ungroup); } catch (e) {} }

    if (want) {
      const buckets = {};
      for (const t of tabs) {
        const c = d.tabs[t.id];
        if (!c || !c.color) continue;
        if (t.groupId !== -1 && !grouped[t.id]) continue; // never steal tabs from the user's own groups
        (buckets[t.windowId + '|' + c.color] ||= []).push(t);
      }
      for (const key of Object.keys(buckets)) {
        const [win, colorId] = key.split('|');
        const col = T.colorOf(colorId);
        if (!col) continue;
        const existing = await chrome.tabGroups.query({ windowId: +win, title: col.name });
        const gid = existing.length ? existing[0].id : null;
        const need = buckets[key].filter(t => t.groupId !== gid);
        if (!need.length) continue;
        const ids = need.map(t => t.id);
        const newGid = await chrome.tabs.group(
          gid != null ? { tabIds: ids, groupId: gid } : { tabIds: ids, createProperties: { windowId: +win } }
        );
        await chrome.tabGroups.update(newGid, { title: col.name, color: col.group });
        ids.forEach(id => { grouped[id] = true; });
      }
    }
    await chrome.storage.local.set({ grouped });
  } catch (e) { /* grouping is best-effort */ }
}

/* ---------- messages from content scripts and popup ---------- */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handle(msg, sender).then(sendResponse).catch(e => sendResponse({ error: String(e) }));
  return true;
});

async function handle(msg, sender) {
  switch (msg && msg.type) {
    case 'get-state': {
      if (!sender.tab) return { error: 'no tab' };
      return stateFor(await load(), sender.tab);
    }
    case 'get-all': {
      const d = await load();
      return { power: d.power, autoGroup: d.autoGroup, tabs: d.tabs };
    }
    case 'set':
      return run(async () => {
        const d = await load();
        const id = msg.tabId;
        const cur = { ...(d.tabs[id] || {}) };
        const p = msg.patch || {};
        if ('color' in p) cur.color = T.colorOf(p.color) ? p.color : '';
        if ('note' in p) cur.note = String(p.note || '').trim().slice(0, T.NOTE_MAX);
        if ('customName' in p) cur.customName = String(p.customName || '').trim().slice(0, T.NAME_MAX);
        if ('highlight' in p) cur.highlight = !!p.highlight;
        d.tabs[id] = cur;
        await chrome.storage.local.set({ tabs: d.tabs });
        await push(await chrome.tabs.get(id), d);
        if ('color' in p) await syncGroups();
        return { ok: true, cfg: cur };
      });
    case 'reset':
      return run(async () => {
        const d = await load();
        delete d.tabs[msg.tabId];
        await chrome.storage.local.set({ tabs: d.tabs });
        await push(await chrome.tabs.get(msg.tabId), d);
        await syncGroups();
        return { ok: true };
      });
    case 'power':
      return run(async () => {
        await chrome.storage.local.set({ power: !!msg.on });
        const d = await load();
        await pushConfigured(d);
        await syncGroups();
        return { ok: true };
      });
    case 'autogroup':
      return run(async () => {
        await chrome.storage.local.set({ autoGroup: !!msg.on });
        await syncGroups();
        return { ok: true };
      });
    default:
      return { error: 'unknown message' };
  }
}

/* ---------- tab lifecycle ---------- */
// Active tab changed: the new tab gets the highlight, the previous one in that window loses it.
chrome.tabs.onActivated.addListener(({ windowId }) => run(async () => {
  const d = await load();
  await pushConfigured(d, { windowId });
}));

chrome.tabs.onRemoved.addListener(tabId => run(async () => {
  const d = await load();
  if (d.tabs[tabId] || d.grouped[tabId]) {
    delete d.tabs[tabId];
    delete d.grouped[tabId];
    await chrome.storage.local.set({ tabs: d.tabs, grouped: d.grouped });
  }
}));

// Prerender/instant swaps give a tab a new ID: carry its settings over.
chrome.tabs.onReplaced.addListener((added, removed) => run(async () => {
  const d = await load();
  if (d.tabs[removed]) {
    d.tabs[added] = d.tabs[removed];
    delete d.tabs[removed];
    await chrome.storage.local.set({ tabs: d.tabs });
    try { await push(await chrome.tabs.get(added), d); } catch (e) {}
  }
}));

// Tab IDs are not stable across browser restarts; stale entries could land on the wrong tab.
chrome.runtime.onStartup.addListener(() => run(() => chrome.storage.local.set({ tabs: {}, grouped: {} })));

chrome.runtime.onInstalled.addListener(() => run(async () => {
  // Label already-open tabs without reloading them (important for queue pages).
  const d = await load();
  const tabs = await chrome.tabs.query({});
  await Promise.all(tabs.filter(t => WEB.test(t.url || '') && !t.discarded).map(async t => {
    try { await inject(t.id); await push(t, d); } catch (e) {}
  }));
}));
