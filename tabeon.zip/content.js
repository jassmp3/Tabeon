/* TABΞON By Jass — content script
 * Only touches document.title and the favicon <link>. No CSS, no page content.
 * Re-applies the label if the site changes its own title, without looping. */
(() => {
  try { if (typeof globalThis.__tabeonTeardown === 'function') globalThis.__tabeonTeardown(); } catch (e) {}

  const T = globalThis.TABEON;
  const FAV_ID = 'tabeon-favicon';
  const STASH = 'tabeon-stashed';

  let cfg = null;
  let orig = document.title;      // the page's own title
  let applied = document.title;   // the last title we set
  let stashed = [];               // site favicon links we temporarily disabled
  let ourLink = null;
  let iconShown = false;
  let observer = null;
  let timer = null;
  let hits = [];
  let dead = false;

  const configured = c => !!(c && c.enabled && (c.color || c.note || c.customName));
  const isIcon = el => !!el && el.tagName === 'LINK' && el.id !== FAV_ID &&
    /(^|\s)icon(\s|$)/i.test(el.getAttribute('rel') || '');

  function throttled() {
    const n = Date.now();
    hits = hits.filter(t => n - t < 2000);
    hits.push(n);
    return hits.length > 25; // a page fighting us: back off
  }

  function compose() {
    if (!configured(cfg)) return orig;
    const col = T.colorOf(cfg.color);
    const act = cfg.active && cfg.highlight;
    const base = cfg.customName ? cfg.customName : (cfg.note ? orig + ' • ' + cfg.note : orig);
    return (act ? '▶ ' : '') + (col ? col.emoji + ' ' : '') + base;
  }

  function renderTitle() {
    if (document.title !== applied) orig = document.title; // page changed it meanwhile
    const t = compose();
    applied = t;
    if (document.title !== t) document.title = t;
  }

  /* ---------- favicon ---------- */
  function drawFavicon(hex, active) {
    const c = document.createElement('canvas');
    c.width = c.height = 64;
    const x = c.getContext('2d');
    const rr = (px, py, w, h, r) => {
      x.beginPath();
      x.moveTo(px + r, py);
      x.arcTo(px + w, py, px + w, py + h, r);
      x.arcTo(px + w, py + h, px, py + h, r);
      x.arcTo(px, py + h, px, py, r);
      x.arcTo(px, py, px + w, py, r);
      x.closePath();
    };
    rr(4, 4, 56, 56, 16); x.fillStyle = hex; x.fill();
    if (active) {
      rr(4, 4, 56, 56, 16); x.lineWidth = 8; x.strokeStyle = '#ffffff'; x.stroke();
      rr(13, 13, 38, 38, 8); x.lineWidth = 5; x.strokeStyle = 'rgba(0,0,0,0.6)'; x.stroke();
    }
    return c.toDataURL('image/png');
  }

  function stashIcon(el) {
    stashed.push({ el, rel: el.getAttribute('rel') });
    el.setAttribute('rel', STASH);
  }

  function showFavicon(hex, active) {
    document.querySelectorAll('link[rel]').forEach(el => { if (isIcon(el)) stashIcon(el); });
    const href = drawFavicon(hex, active);
    if (!ourLink) {
      ourLink = document.createElement('link');
      ourLink.id = FAV_ID;
      ourLink.rel = 'icon';
      ourLink.type = 'image/png';
    }
    if (ourLink.getAttribute('href') !== href) ourLink.setAttribute('href', href);
    if (!ourLink.isConnected) (document.head || document.documentElement).appendChild(ourLink);
    iconShown = true;
  }

  function hideFavicon() {
    if (!iconShown) return;
    iconShown = false;
    if (ourLink && ourLink.isConnected) ourLink.remove();
    const had = stashed.length > 0;
    stashed.forEach(s => { if (s.el.getAttribute('rel') === STASH) s.el.setAttribute('rel', s.rel); });
    stashed = [];
    if (!had && /^https?:$/.test(location.protocol)) {
      // The site declared no icon link; point the browser back at its default location.
      const l = document.createElement('link');
      l.rel = 'icon';
      l.href = location.origin + '/favicon.ico';
      (document.head || document.documentElement).appendChild(l);
    }
  }

  function renderIcon() {
    const col = configured(cfg) ? T.colorOf(cfg.color) : null;
    if (col) showFavicon(col.hex, !!(cfg.active && cfg.highlight));
    else hideFavicon();
  }

  function render() {
    if (dead && cfg) return;
    renderTitle();
    renderIcon();
  }

  /* ---------- observe site changes ---------- */
  function onMut(records) {
    if (dead) return;
    if (iconShown) {
      for (const r of records) {
        if (r.type === 'childList') {
          r.addedNodes.forEach(n => { if (isIcon(n)) stashIcon(n); });
        } else if (r.type === 'attributes' && isIcon(r.target)) {
          stashIcon(r.target);
        }
      }
      if (ourLink && !ourLink.isConnected) (document.head || document.documentElement).appendChild(ourLink);
    }
    if (document.title !== applied) {
      if (throttled()) {
        clearTimeout(timer);
        timer = setTimeout(renderTitle, 3000);
      } else {
        renderTitle();
      }
    }
  }

  const target = document.head || document.documentElement;
  observer = new MutationObserver(onMut);
  observer.observe(target, {
    childList: true, subtree: true, characterData: true,
    attributes: true, attributeFilter: ['rel', 'href']
  });

  /* ---------- messaging ---------- */
  const listener = (msg, sender, sendResponse) => {
    if (!msg) return;
    if (msg.type === 'tabeon-state') {
      cfg = msg.state;
      render();
      sendResponse(true);
    } else if (msg.type === 'tabeon-query') {
      if (document.title !== applied) orig = document.title;
      sendResponse({ orig });
    }
  };
  chrome.runtime.onMessage.addListener(listener);

  globalThis.__tabeonTeardown = () => {
    clearTimeout(timer);
    cfg = null;
    try { renderTitle(); renderIcon(); } catch (e) {}
    dead = true;
    try { observer.disconnect(); } catch (e) {}
    try { chrome.runtime.onMessage.removeListener(listener); } catch (e) {}
  };

  try {
    chrome.runtime.sendMessage({ type: 'get-state' }).then(s => {
      if (s && !s.error) { cfg = s; render(); }
    }).catch(() => {});
  } catch (e) {}
})();
