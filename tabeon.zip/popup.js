(() => {
  const T = TABEON;
  const $ = s => document.querySelector(s);
  const send = m => chrome.runtime.sendMessage(m);
  const WEB = /^(https?|file):/i;
  const isCfg = c => !!(c && (c.color || c.note || c.customName));

  let cur = null;
  let data = { power: true, autoGroup: false, tabs: {} };
  let tabsList = [];

  const domainOf = url => {
    try { return new URL(url).hostname.replace(/^www\./, '') || url; } catch (e) { return url || ''; }
  };

  function flash(el) {
    el.textContent = 'SAVED';
    el.classList.add('show');
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.remove('show'), 1400);
  }

  async function setPatch(patch) {
    const res = await send({ type: 'set', tabId: cur.id, patch });
    if (res && res.cfg) data.tabs[cur.id] = res.cfg;
    render();
    renderList();
    return res;
  }

  /* ---------- palette ---------- */
  function buildPalette() {
    const pal = $('#palette');
    T.COLORS.forEach(c => {
      const b = document.createElement('button');
      b.className = 'sw';
      b.style.setProperty('--c', c.hex);
      b.title = c.label;
      b.dataset.id = c.id;
      b.setAttribute('aria-label', c.label);
      b.addEventListener('click', () => {
        b.classList.remove('pulse'); void b.offsetWidth; b.classList.add('pulse');
        setPatch({ color: c.id });
      });
      pal.appendChild(b);
    });
  }

  /* ---------- current tab ---------- */
  function render() {
    const cfg = data.tabs[cur.id] || {};
    document.body.classList.toggle('off', !data.power);
    $('#power').checked = !!data.power;
    $('#powerTxt').textContent = data.power ? 'ON' : 'OFF';
    $('#autoGroup').checked = !!data.autoGroup;
    $('#highlight').checked = cfg.highlight !== false;
    document.querySelectorAll('#palette .sw').forEach(b => b.classList.toggle('sel', b.dataset.id === cfg.color));
    $('#ctitle').textContent = cur._title || cur.title || cur.url || 'New tab';
    $('#cdomain').textContent = domainOf(cur.url);
    $('#hint').hidden = WEB.test(cur.url || '');
    const fav = $('#fav');
    if (cur.favIconUrl) { fav.src = cur.favIconUrl; fav.style.visibility = 'visible'; }
    else fav.style.visibility = 'hidden';
  }

  function fillInputs() {
    const cfg = data.tabs[cur.id] || {};
    $('#note').value = cfg.note || '';
    $('#name').value = cfg.customName || '';
  }

  /* ---------- all tabs ---------- */
  async function loadTabs() {
    tabsList = await chrome.tabs.query({});
    tabsList.sort((a, b) =>
      (a.windowId === cur.windowId ? -1 : 0) - (b.windowId === cur.windowId ? -1 : 0) ||
      a.windowId - b.windowId || a.index - b.index);
    // Titles of labeled tabs include our decoration, so ask each tab for its real title.
    await Promise.all(tabsList.map(async t => {
      t._title = t.title || '';
      if (data.power && isCfg(data.tabs[t.id]) && WEB.test(t.url || '')) {
        try {
          const r = await chrome.tabs.sendMessage(t.id, { type: 'tabeon-query' });
          if (r && typeof r.orig === 'string') t._title = r.orig;
        } catch (e) {}
      }
    }));
    const me = tabsList.find(t => t.id === cur.id);
    if (me) cur._title = me._title;
  }

  function renderList() {
    const q = $('#search').value.trim().toLowerCase();
    const list = $('#list');
    list.textContent = '';
    let shown = 0;
    for (const t of tabsList) {
      const cfg = data.tabs[t.id] || {};
      const title = t._title || t.title || '';
      const domain = domainOf(t.url);
      const hay = [cfg.customName, cfg.note, title, domain].join(' ').toLowerCase();
      if (q && !hay.includes(q)) continue;
      shown++;

      const col = T.colorOf(cfg.color);
      const row = document.createElement('button');
      row.className = 'tab' + (t.id === cur.id ? ' current' : '');
      row.style.setProperty('--c', col ? col.hex : '#4d5a78');

      const dot = document.createElement('span');
      dot.className = 'dot' + (col ? '' : ' none');
      row.appendChild(dot);

      const body = document.createElement('div');
      body.className = 'tb';
      const t1 = document.createElement('div');
      t1.className = 't1';
      const lab = document.createElement('span');
      lab.className = 'lab';
      lab.textContent = cfg.customName || cfg.note || title || domain || 'Untitled';
      t1.appendChild(lab);
      if (cfg.customName && cfg.note) {
        const chip = document.createElement('span');
        chip.className = 'chip';
        chip.textContent = cfg.note;
        t1.appendChild(chip);
      }
      const t2 = document.createElement('div');
      t2.className = 't2';
      t2.textContent = [title, domain].filter(Boolean).join(' · ');
      body.append(t1, t2);
      row.appendChild(body);

      row.addEventListener('click', async () => {
        await chrome.tabs.update(t.id, { active: true });
        await chrome.windows.update(t.windowId, { focused: true });
        window.close();
      });
      list.appendChild(row);
    }
    if (!shown) {
      const e = document.createElement('div');
      e.className = 'empty';
      e.textContent = 'No matching tabs';
      list.appendChild(e);
    }
    $('#count').textContent = q ? shown + ' / ' + tabsList.length : String(tabsList.length);
  }

  /* ---------- events ---------- */
  function bind() {
    $('#power').addEventListener('change', async e => {
      data.power = e.target.checked;
      render();
      await send({ type: 'power', on: data.power });
      await loadTabs();
      renderList();
    });
    $('#autoGroup').addEventListener('change', e => {
      data.autoGroup = e.target.checked;
      send({ type: 'autogroup', on: data.autoGroup });
    });
    $('#highlight').addEventListener('change', e => setPatch({ highlight: e.target.checked }));

    const saveNote = async () => { await setPatch({ note: $('#note').value }); fillInputs(); flash($('#noteSaved')); };
    $('#noteBtn').addEventListener('click', saveNote);
    $('#note').addEventListener('keydown', e => { if (e.key === 'Enter') saveNote(); });

    const saveName = async () => { await setPatch({ customName: $('#name').value }); fillInputs(); flash($('#nameSaved')); };
    $('#nameBtn').addEventListener('click', saveName);
    $('#name').addEventListener('keydown', e => { if (e.key === 'Enter') saveName(); });
    $('#nameReset').addEventListener('click', async () => {
      $('#name').value = '';
      await setPatch({ customName: '' });
      flash($('#nameSaved'));
    });

    $('#resetTab').addEventListener('click', async () => {
      await send({ type: 'reset', tabId: cur.id });
      delete data.tabs[cur.id];
      fillInputs();
      render();
      await loadTabs();
      renderList();
    });

    $('#search').addEventListener('input', renderList);
  }

  async function init() {
    [cur] = await chrome.tabs.query({ active: true, currentWindow: true });
    data = await send({ type: 'get-all' });
    $('#quote').textContent = '“' + T.QUOTES[Math.floor(Math.random() * T.QUOTES.length)] + '”';
    buildPalette();
    bind();
    fillInputs();
    render();
    await loadTabs();
    render();
    renderList();
  }

  init();
})();
