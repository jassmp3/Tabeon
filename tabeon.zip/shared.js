/* TABΞON By Jass — shared constants (used by background, content script and popup) */
globalThis.TABEON = (() => {
  const COLORS = [
    { id: 'red',    name: 'RED',    label: 'Neon Red',    hex: '#ff2d55', emoji: '🔴', group: 'red' },
    { id: 'orange', name: 'ORANGE', label: 'Neon Orange', hex: '#ff8a1f', emoji: '🟠', group: 'orange' },
    { id: 'yellow', name: 'YELLOW', label: 'Neon Yellow', hex: '#ffe81a', emoji: '🟡', group: 'yellow' },
    { id: 'green',  name: 'GREEN',  label: 'Neon Green',  hex: '#2dff7a', emoji: '🟢', group: 'green' },
    { id: 'cyan',   name: 'CYAN',   label: 'Neon Cyan',   hex: '#19f0ff', emoji: '🔷', group: 'cyan' },
    { id: 'blue',   name: 'BLUE',   label: 'Neon Blue',   hex: '#3d7bff', emoji: '🔵', group: 'blue' },
    { id: 'purple', name: 'PURPLE', label: 'Neon Purple', hex: '#a259ff', emoji: '🟣', group: 'purple' },
    { id: 'pink',   name: 'PINK',   label: 'Neon Pink',   hex: '#ff3fd0', emoji: '💗', group: 'pink' },
    { id: 'white',  name: 'WHITE',  label: 'Neon White',  hex: '#f4f8ff', emoji: '⚪', group: 'grey' },
    { id: 'gray',   name: 'GRAY',   label: 'Neutral Gray', hex: '#7b8499', emoji: '⚫', group: 'grey' }
  ];
  const QUOTES = [
    "Yes, they're all the same tab.",
    'Color coding is productivity.',
    'One tab was never enough.',
    'Future you will thank you.',
    'Because tabs deserve names too.',
    'Totally organized. Probably.',
    'Professional tab hoarding.',
    '12 tabs. Zero regrets.',
    'Ctrl+Tab but make it fancy.',
    'Your browser called. It wants fewer tabs.'
  ];
  return {
    NOTE_MAX: 40,
    NAME_MAX: 40,
    COLORS,
    QUOTES,
    colorOf: id => COLORS.find(c => c.id === id) || null
  };
})();
